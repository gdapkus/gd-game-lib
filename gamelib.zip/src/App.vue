<template>
  <div>
    <Games />
  </div>
</template>

<script>
import Games from '@/components/Games.vue'; // Adjust the path if needed

export default {
  components: {
    Games
  }
};
</script>
